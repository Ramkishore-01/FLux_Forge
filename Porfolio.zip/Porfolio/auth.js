// routes/auth.js
const router = require("express").Router();
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const Admin = require("../models/Admin");

router.post("/login", async (req, res) => {
  const { email, password } = req.body;

  const admin = await Admin.findOne({ email });
  if (!admin) return res.status(400).json("User not found");

  const valid = await bcrypt.compare(password, admin.password);
  if (!valid) return res.status(400).json("Wrong password");

  const token = jwt.sign({ id: admin._id }, "secret123");
  res.json({ token });
});

module.exports = router;