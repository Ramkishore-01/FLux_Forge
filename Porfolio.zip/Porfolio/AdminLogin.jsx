// pages/AdminLogin.jsx
import { useState } from "react";
import axios from "axios";

export default function AdminLogin() {
  const [data, setData] = useState({ email: "", password: "" });

  const handleLogin = async () => {
    const res = await axios.post("http://localhost:5000/api/auth/login", data);
    localStorage.setItem("token", res.data.token);
    alert("Login Success");
  };

  return (
    <div className="p-10">
      <input placeholder="Email" onChange={(e)=>setData({...data,email:e.target.value})}/>
      <input type="password" placeholder="Password" onChange={(e)=>setData({...data,password:e.target.value})}/>
      <button onClick={handleLogin}>Login</button>
    </div>
  );
}