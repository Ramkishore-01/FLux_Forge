// components/Services.jsx
const services = [
  "Web Development",
  "React Frontend",
  "Data Analytics",
  "Dashboard Development"
];

export default function Services() {
  return (
    <section className="p-10">
      <h2 className="text-2xl font-bold text-center">Our Services</h2>
      <div className="grid md:grid-cols-4 gap-6 mt-6">
        {services.map((s, i) => (
          <div key={i} className="p-4 shadow rounded text-center">
            {s}
          </div>
        ))}
      </div>
    </section>
  );
}