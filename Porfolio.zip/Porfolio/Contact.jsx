// components/Contact.jsx
import { useState } from "react";

export default function Contact() {
  const [form, setForm] = useState({ name: "", email: "", message: "" });

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(form); // connect backend later
  };

  return (
    <section className="p-10 bg-gray-100">
      <h2 className="text-2xl font-bold text-center">Contact Us</h2>

      <form onSubmit={handleSubmit} className="max-w-md mx-auto mt-6">
        <input
          type="text"
          placeholder="Name"
          className="w-full p-2 mb-3 border"
          onChange={(e) => setForm({ ...form, name: e.target.value })}
        />
        <input
          type="email"
          placeholder="Email"
          className="w-full p-2 mb-3 border"
          onChange={(e) => setForm({ ...form, email: e.target.value })}
        />
        <textarea
          placeholder="Message"
          className="w-full p-2 mb-3 border"
          onChange={(e) => setForm({ ...form, message: e.target.value })}
        />
        <button className="bg-blue-500 text-white px-4 py-2 w-full">
          Send
        </button>
      </form>
    </section>
  );
}