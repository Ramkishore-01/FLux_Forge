// components/Hero.jsx
export default function Hero() {
  return (
    <section className="h-screen flex flex-col justify-center items-center text-center">
      <h1 className="text-4xl font-bold">We Build Digital Experiences</h1>
      <p className="mt-4">Flux Forge - Web & Data Solutions</p>
      <button className="mt-6 bg-blue-500 text-white px-6 py-2 rounded">
        Hire Us
      </button>
    </section>
  );
}