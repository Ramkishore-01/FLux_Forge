// components/Projects.jsx
const projects = [
  {
    name: "Dashboard App",
    tech: "React, Power BI",
  },
  {
    name: "E-commerce Site",
    tech: "React, Node.js",
  },
];

export default function Projects() {
  return (
    <section className="p-10 bg-gray-100">
      <h2 className="text-2xl font-bold text-center">Projects</h2>
      <div className="grid md:grid-cols-2 gap-6 mt-6">
        {projects.map((p, i) => (
          <div key={i} className="p-4 bg-white shadow rounded">
            <h3 className="font-bold">{p.name}</h3>
            <p>{p.tech}</p>
          </div>
        ))}
      </div>
    </section>
  );
}