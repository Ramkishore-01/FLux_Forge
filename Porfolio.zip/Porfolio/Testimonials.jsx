// components/Testimonials.jsx
const testimonials = [
  {
    name: "Client A",
    feedback: "Amazing work!",
  },
  {
    name: "Client B",
    feedback: "Highly recommend!",
  },
];

export default function Testimonials() {
  return (
    <section className="p-10">
      <h2 className="text-2xl font-bold text-center">Testimonials</h2>
      <div className="grid md:grid-cols-2 gap-6 mt-6">
        {testimonials.map((t, i) => (
          <div key={i} className="p-4 border rounded">
            <p>"{t.feedback}"</p>
            <h4 className="mt-2 font-bold">- {t.name}</h4>
          </div>
        ))}
      </div>
    </section>
  );
}