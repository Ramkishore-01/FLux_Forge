// pages/Dashboard.jsx
import { useEffect, useState } from "react";
import axios from "axios";

export default function Dashboard() {
  const [projects, setProjects] = useState([]);
  const [form, setForm] = useState({ title: "", description: "", tech: "" });

  const fetchProjects = async () => {
    const res = await axios.get("http://localhost:5000/api/projects");
    setProjects(res.data);
  };

  useEffect(() => {
    fetchProjects();
  }, []);

  const addProject = async () => {
    await axios.post("http://localhost:5000/api/projects", form);
    fetchProjects();
  };

  const deleteProject = async (id) => {
    await axios.delete(`http://localhost:5000/api/projects/${id}`);
    fetchProjects();
  };

  return (
    <div className="p-10">
      <h1>Admin Dashboard</h1>

      {/* Add Project */}
      <input placeholder="Title" onChange={(e)=>setForm({...form,title:e.target.value})}/>
      <input placeholder="Tech" onChange={(e)=>setForm({...form,tech:e.target.value})}/>
      <button onClick={addProject}>Add</button>

      {/* List */}
      {projects.map(p => (
        <div key={p._id}>
          <h3>{p.title}</h3>
          <button onClick={()=>deleteProject(p._id)}>Delete</button>
        </div>
      ))}
    </div>
  );
}